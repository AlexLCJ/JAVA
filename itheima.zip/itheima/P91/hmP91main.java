package com.itheima.P91;

public class hmP91main {
    public static void main(String[] args) {
        Role role1 = new Role("a",100,'男');
        Role role2 = new Role("b",100,'男');


        //展示角色
        role1.showRoleInfo();
        role2.showRoleInfo();

        System.out.println();

        while(true){
            role1.attack(role2);
            if(role2.getBlood()==0){
                System.out.println(role1.getName()+" ko "+role2.getName());
                break;
            }

            role2.attack(role1);
            if(role1.getBlood()==0){
                System.out.println(role2.getName()+" ko "+role1.getName());
                break;
            }
        }

    }
}
