package com.itheima.P91;

import java.util.Random;

public class Role {
    private String name;
    private int blood;
    private char gender;
    private String face; //random face

    String[] boyfaces = {"风流倜傥", "气宇轩昂", "英俊潇洒", "五官端正", "相貌平平", "一塌糊涂", "面目狰狞"};
    String[] girlfaces = {"美奂绝伦", "沉鱼落雁", "亭亭玉立", "身材娇好", "相貌平平", "相貌简陋", "惨不忍睹"};

    String[] attack_desc = {
            "%s使出一招【背心钉】，转到对方身后，一掌拍向了%s的灵台穴。",
            "%s使出一招【游空探爪】，飞起身形自空中变掌为爪锁住%s。"
    };

    String[] injured_desc = {
            "结果%s退了半步，毫发无损。",
            "结果给%s造成了瘀伤。",
            "结果%s痛苦滴嗯了一声，显然受了内伤。",
            "结果%s一声惨叫。"
    };


    public Role() {
    }

    public Role(String name, int blood, char gender) {
        this.name = name;
        this.blood = blood;
        this.gender = gender;
        setFace(gender);
    }


    public String getFace() {
        return face;
    }

    public void setFace(char gender) {
        //随机长相
        Random r = new Random();
        if (gender == '男') {
            int index = r.nextInt(boyfaces.length);
            this.face = boyfaces[index];

        } else if (gender == '女') {
            int index = r.nextInt(girlfaces.length);
            this.face = girlfaces[index];
        } else {
            this.face = "面目狰狞";
        }

    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    /**
     * 获取
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置
     *
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取
     *
     * @return blood
     */
    public int getBlood() {
        return blood;
    }

    /**
     * 设置
     *
     * @param blood
     */
    public void setBlood(int blood) {
        this.blood = blood;
    }

    public String toString() {
        return "Role{name = " + name + ", blood = " + blood + "}";
    }

    //攻击
    public void attack(Role role) {
        //输出攻击效果
        Random r = new Random();
        int index = r.nextInt(attack_desc.length);
        String kungfu = attack_desc[index];

        System.out.printf(kungfu, this.getName(), role.getName());

        //计算伤害
        int hurt = r.nextInt(20) + 1;

        //剩余血量
        int remainBlood = role.getBlood() - hurt;
        remainBlood = remainBlood < 0 ? 0 : remainBlood;
        role.setBlood(remainBlood);

        //受伤描述
        //根绝血量来描述
        if(remainBlood>75){
            System.out.printf(injured_desc[0],role.getName());
        } else if (remainBlood>50) {
            System.out.printf(injured_desc[1],role.getName());
        } else if (remainBlood>25) {
            System.out.printf(injured_desc[2],role.getName());
        }else {
            System.out.printf(injured_desc[3],role.getName());
        }


        System.out.println(this.name + "攻击了" + role.getName() + "造成了" + hurt + "伤害." + role.getName() + "剩下"
                + role.getBlood() + "血量");
    }

    public void showRoleInfo() {
        System.out.println("姓名：" + getName());
        System.out.println("血量：" + getBlood());
        System.out.println("性别：" + getGender());
        System.out.println("长相：" + getFace());
    }

}
