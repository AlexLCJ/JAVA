package com.itheima.zifuchuan;

public class P98main {
    public static void main(String[] args) {
        String s1 = "abc";
        System.out.println(s1);

        //空参构造
        String s2 = new String();
        System.out.println("@"+s2+"!");

        //传递一个字符串
        String s3 = new String("abc");
        System.out.println(s3);

        //传递一个字符数组
        //需求：修改字符串的内容：变成数组再修改
        char[] chs = {'a','b','c','d'};
        String s4 = new String(chs);
        System.out.println(s4);

        //传递一个字节数组
        //应用：网络中传输的都是字节信息
        //一般把字节信息转化为字符串
        byte[] bytes = {97,98,99,100}; //asc2码查找
        String s5 = new String(bytes);
        System.out.println(s5);


    }
}

