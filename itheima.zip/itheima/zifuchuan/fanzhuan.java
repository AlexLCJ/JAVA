package com.itheima.zifuchuan;

public class fanzhuan {
    public static void main(String[] args) {
        reverser("avd");
    }

    public static String reverser(String str){
        //abc->cba
        for (int i = str.length() - 1; i >= 0; i--) { //str.length().forr //倒着遍历
            //i means: index
            char c = str.charAt(i);
            System.out.println(c);
        }

        return "";
    }
}
