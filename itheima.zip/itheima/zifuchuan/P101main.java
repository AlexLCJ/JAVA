package com.itheima.zifuchuan;

import java.util.Scanner;

public class P101main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string");
        String str = sc.next();

        for (int i = 0; i < str.length(); i++) {//str.length().fori
            //i依次表示字符串的每一个索引
            char c = str.charAt(i); //遍历
            System.out.println(c);
        }
    }
}
