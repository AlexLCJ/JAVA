package com.itheima.zifuchuan;

import java.util.Scanner;

public class P100main {
    public static void main(String[] args) {
        String rightUserName = "zhangsan";
        String rightPassword = "123456";


        for (int i = 0; i < 3; i++) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter the username:");
            String username = scanner.next();
            System.out.println("Enter the password:");
            String password = scanner.next();

            if (username.equals(rightUserName) && password.equals(rightPassword)) {
                System.out.println("login");
                break;
            }else {
                System.out.println("wrong!");
            }

        }
    }
}
