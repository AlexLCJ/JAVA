package com.itheima.zifuchuan;

public class P99main {
    public static void main(String[] args) {
        //基本数据类型比较的是数据值
        //引用数据类型比较的是地址值
        /*
         *字符串的比较：
         * boolean equals(要比较的字符串)
         * boolean equalsIgnoreCase(要比较的字符串)  忽略大小写 */
        String s1 = new String("abc");
        String s2 = "Abc";
        System.out.println(s1 == s2);  //false

        //比较字符串中的内容：
        boolean equals = s1.equals(s2);
        System.out.println(equals);

        boolean result = s1.equalsIgnoreCase(s2);
        System.out.println(result);

    }
}
