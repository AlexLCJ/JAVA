package com.itheima.test;

public class PhoneTest {
    public static void main(String[] args) {
        Phone P = new Phone();

        P.brand="xiaomi";
        P.price=1989;

        P.call();
        P.playGame();

        System.out.println(P.brand);
        System.out.println(P.price);
    }
}
