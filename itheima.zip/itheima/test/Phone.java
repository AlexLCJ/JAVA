package com.itheima.test;

public class Phone {

    //属性
    String brand;
    double price;

    //行为
    public void call(){
        System.out.println("正在打电话");
    }
    public void playGame(){
        System.out.println("正在玩游戏");
    }


}


