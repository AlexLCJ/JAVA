package com.itheima.P94;


public class P94main {
    public static void main(String[] args) {
        //创建一个数组，用来存储学生对象
        Student[] arr = new Student[3];

        //创建学生对象
        Student stu1 = new Student(1, "张三", 23);
        Student stu2 = new Student(2, "李四", 24);
        //Student stu3 = new Student(3, "张王五", 25);

        arr[0] = stu1;
        arr[1] = stu2;
        //arr[2] = stu3;

        //要求1.再次添加一个学生对象，并进行学号的唯一性判断
        Student stu4 = new Student(4, "赵六", 26);

        boolean flag = contains(arr, stu4.getId()); //查询id
        if (flag) {
            System.out.println("当前id重复");
        } else {
            int count = getCount(arr);
            if (count == arr.length) {
                //存满
                //创建一个新的数组 长度=老数组+1，把老数组元素copy到新数组。
                Student[] newArr = creatNewArr(arr);
                //[stu1,stu2,stu3]
                //[stu1,stu2,stu3,null]
                //添加新的元素
                newArr[count] = stu4;

                //要求2.遍历打印
                printArr(newArr);

            } else {
                //没有存满
                //[stu1,stu2,null] getCount获取到2,同时表示，下一次添加数据，添加到2索引位置
                arr[count] = stu4;

                //要求2.遍历
                printArr(arr);
            }
        }

    }

    //打印元素
    public static void printArr(Student[] arr) {
        for (int i = 0; i < arr.length; i++) {
            Student stu = arr[i];
            if (stu != null) {
                System.out.println(stu.getId() + ", " + stu.getName() + ", " + stu.getAge());
            }
        }
    }

    //唯一性判断，需要返回
    public static boolean contains(Student[] arr, int id) {
        for (int i = 0; i < arr.length; i++) {
            Student stu = arr[i];
            //增加非空判断，否则无法使用数组的getid等操作。
            if (stu != null) {
                int sid = stu.getId();
                if (sid == id) {
                    return true;
                }
            }

        }
        return false;
    }

    //定义一个方法判断已经存在多少个元素
    public static int getCount(Student[] arr) {
        //定义一个计数器统计
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != null) {
                count++;
            }
        }
        return count;
    }

    //创建一个新的数组
    public static Student[] creatNewArr(Student[] arr) {
        Student[] newArr = new Student[arr.length + 1];

        for (int i = 0; i < arr.length; i++) {
            //把老数组中的元素添加到新数组
            newArr[i] = arr[i];
        }
        //return
        return newArr;

    }


}
