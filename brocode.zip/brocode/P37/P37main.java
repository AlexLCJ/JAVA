package com.brocode.P37;

public class P37main {
    public static void main(String[] args) {
        //学习public, protected, private;

    }
}
