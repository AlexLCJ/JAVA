package com.brocode.P31;

public class Food {

    String name;

    Food(String name){
        this.name = name;
    }
}
