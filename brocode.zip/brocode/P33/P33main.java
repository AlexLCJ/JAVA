package com.brocode.P33;

public class P33main {
    public static void main(String[] args) {
        Friend friend1=new Friend("Sjdnf");
        Friend friend2=new Friend("dfa");


        System.out.println(Friend.numbeOffFriends);

    }
}
