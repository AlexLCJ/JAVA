package com.brocode.P33;

public class Friend {
    String name;
    static int numbeOffFriends;

    Friend(String name){
        this.name=name;
        numbeOffFriends++;
    }

}
