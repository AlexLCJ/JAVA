package com.brocode.P36;

public class P36main {
    public static void main(String[] args) {
        Hero hero1 = new Hero("Batman",42,"$$$");

        System.out.println(hero1.name);
        System.out.println(hero1.age);

    }

}
