package com.brocode.P30;

public class P30main {
    public static void main(String[] args) {
        Car car = new Car();

//        System.out.println(car.name);
//        System.out.println(car.model);
//        System.out.println(car.color);
//        System.out.println(car.year);

        //System.out.println(car.toString());
        System.out.println(car);


    }
}
