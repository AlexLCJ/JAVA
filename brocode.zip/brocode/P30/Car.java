package com.brocode.P30;

public class Car {

    String name = "Ford";
    String model = "Mustang";
    String color = "red";
    int year = 2021;

    public String toString(){
        String myString = name + "\n"+model+"\n"+color +"\n"+year;
        return myString;
    }

}
