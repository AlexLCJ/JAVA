package com.brocode.P35;

public class P35main {
    //在子类中记得打上：@Override
}
