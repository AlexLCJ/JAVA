package com.brocode.P32;

public class Garage {

    void park(Car car){
        System.out.println("The "+car.name+" is parked");
    }

}
