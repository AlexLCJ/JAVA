package com.brocode.P32;

public class Car {

    String name;

    Car(String name){
        this.name = name;
    }

}
