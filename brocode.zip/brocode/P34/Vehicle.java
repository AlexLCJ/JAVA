package com.brocode.P34;

public class Vehicle {

    double speed;

    void go(){
        System.out.println("This is moving");
    }

    void stop(){
        System.out.println("This is stopped");
    }
}
