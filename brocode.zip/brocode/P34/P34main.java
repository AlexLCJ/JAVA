package com.brocode.P34;

public class P34main {
    public static void main(String[] args) {
        //继承

        Car car = new Car();
        car.go();

        Bicycle bicycle = new Bicycle();
        bicycle.stop();

        System.out.println(car.doors);
        System.out.println(bicycle.peddles);

    }
}
