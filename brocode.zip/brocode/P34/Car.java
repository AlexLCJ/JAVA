package com.brocode.P34;

public class Car extends Vehicle{
    int wheels = 4;
    int doors = 4;


}
