package com.brocode.P34;

public class Bicycle extends Vehicle{
    int wheels = 2;
    int peddles = 2;

}
